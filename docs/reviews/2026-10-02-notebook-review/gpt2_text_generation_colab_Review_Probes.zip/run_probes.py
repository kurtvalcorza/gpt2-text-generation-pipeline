"""Review probes for tutorials/gpt2_text_generation_colab.ipynb (gpt2-text-generation-pipeline).

Row 31 of the 2026-10-02 notebook review relay. CPU only. No GPU, no install.
Model-backed probes (P4) use a STAND-IN: a randomly initialised 12-block GPT-2 with n_embd=32 and a
byte-level toy tokenizer, wired exactly like `from_pretrained`'s closures. They test control flow and
state semantics (what `adapt` starts from, what `save_artifact` captures), not model quality.

Usage:  python run_probes.py <repo_worktree> <out_dir>
Writes <out_dir>/results.json and <out_dir>/source_manifest.json.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
NB_PATH = REPO / "tutorials" / "gpt2_text_generation_colab.ipynb"
results: dict = {"probes": {}, "env": {"python": sys.version.split()[0], "platform": sys.platform}}


def record(name, payload):
    results["probes"][name] = payload
    (OUT / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]

# ---- P0 static -------------------------------------------------------------------------------------
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
compile_ok = {}
for i in code_idx:
    try:
        ast.parse(src[i])
        compile_ok[i] = True
    except SyntaxError as exc:
        compile_ok[i] = str(exc)
md = "\n".join(s for c, s in zip(cells, src) if c["cell_type"] == "markdown")
low = md.lower()
markers = {k: (k in low) for k in [
    "how to use", "roadmap", "glossary", "predict", "what to notice", "check your reasoning",
    "troubleshoot", "learner", "infrastructure", "conclusion", "restart", "re-run", "rerun", "look for", "watch",
]}
asserts = []
for i in code_idx:
    for node in ast.walk(ast.parse(src[i])):
        if isinstance(node, ast.Assert):
            asserts.append({"cell": i, "line": node.lineno, "has_message": node.msg is not None})
record("P0_static", {
    "nbformat": [nb["nbformat"], nb["nbformat_minor"]],
    "n_cells": len(cells), "code_cells": code_idx,
    "compile_ok": compile_ok,
    "metadata_dimer": nb["metadata"].get("dimer"),
    "outputs_or_counts": sum(bool(cells[i].get("outputs")) or cells[i].get("execution_count") is not None for i in code_idx),
    "carried_module_lines": {i: src[i].count("\n") + 1 for i in (5, 7, 9)},
    "cellView_form_cells": [i for i in code_idx if cells[i].get("metadata", {}).get("cellView") == "form"],
    "guided_markers_in_markdown": markers,
    "double_brace_markdown": [(i, s.count("{{")) for i, s in enumerate(src) if cells[i]["cell_type"] == "markdown" and "{{" in s],
    "byod_upload": {"files.upload": "files.upload()" in src[13], "location_field": "BYOD_PATH" in src[13] or "_PATH =" in src[13]},
    "asserts": asserts,
    "install_cell_raises_restart": "Restart the runtime" in src[3],
    "markdown_mentions_restart_outside_install_heading": [i for i, s in enumerate(src) if cells[i]["cell_type"] == "markdown" and "restart" in s.lower()],
    "env_var_read": "DIMER_NOTEBOOK_CI_PREINSTALLED" in src[3],
    "env_var_documented_in_markdown": "DIMER_NOTEBOOK_CI_PREINSTALLED" in md,
    "spec_declared": nb["metadata"]["dimer"]["notebook_spec"],
    "section9_prompt_print_slice": "head[-60:]" in src[23],
})

# ---- P1 carried cells execute in one namespace --------------------------------------------------------
work = Path(tempfile.mkdtemp(prefix="gpt2r31_"))
os.chdir(work)
import types
_kmod = types.ModuleType("nb_kernel")  # stands in for the kernel __main__ (harness detail)
sys.modules["nb_kernel"] = _kmod
ns: dict = _kmod.__dict__
t0 = time.perf_counter()
for i in (5, 7, 9):
    exec(compile(src[i], f"cell{i}", "exec"), ns)
pkg_dir = REPO / "src" / "gpt2_text_generation_pipeline"
record("P1_carried_cells", {
    "ok": True, "seconds": round(time.perf_counter() - t0, 2),
    "DEFAULT_WEIGHTS_DIR": str(ns["DEFAULT_WEIGHTS_DIR"]),
    "names": sorted(k for k in ("GPT2TextGenerationPipeline", "fetch_corpus", "read_corpus", "build_sample_dataset",
                                  "split_dataset", "load_byod_dataset", "validate_dataset", "check_split_disjoint",
                                  "sequence_metrics", "unigram_baseline") if k in ns),
})

# ---- P2 cell 13 at defaults (real fetch of the pinned SciTLDR files) ----------------------------------
try:
    t0 = time.perf_counter()
    ns["os"] = os
    ns["Path"] = Path
    exec(compile(src[13], "cell13", "exec"), ns)
    record("P2_cell13_default", {
        "ok": True, "seconds": round(time.perf_counter() - t0, 1),
        "raw_papers": ns["raw_papers"], "splits": ns["disjoint"],
        "digests": {k: v["digest"][:16] for k, v in ns["dataset_manifests"].items()},
    })
except Exception as exc:  # network etc.
    record("P2_cell13_default", {"ok": False, "error": repr(exc)[:400]})

# ---- P3 BYOD contract ----------------------------------------------------------------------------
load_byod, split, validate = ns["load_byod_dataset"], ns["split_dataset"], ns["validate_dataset"]
byod = {}
for n in (8, 10, 11, 12, 13):
    p = work / f"byod_{n}.csv"
    rows = "\n".join(f"d{k},Document number {k} talks about topic {k * 7} in some detail." for k in range(n))
    p.write_text("id,text\n" + rows + "\n", encoding="utf-8")
    recs = load_byod(p)
    entry = {}
    try:
        validate(recs)
        entry["validate_dataset"] = "accepted"
    except Exception as exc:
        entry["validate_dataset"] = repr(exc)[:160]
    try:
        s = split(recs, seed=42)
        entry["split_dataset"] = {k: len(v) for k, v in s.items()}
        entry["section5_unseen_records_from_test[1:4]"] = len(s["test"][1:4])
    except Exception as exc:
        entry["split_dataset"] = repr(exc)[:200]
    byod[f"csv_{n}_records"] = entry
bad = work / "bad.csv"
bad.write_text("doc,body\na,hello world text\n", encoding="utf-8")
try:
    load_byod(bad)
except Exception as exc:
    byod["csv_wrong_columns"] = repr(exc)[:200]
empty = work / "empty.csv"
empty.write_text("id,text\n", encoding="utf-8")
try:
    load_byod(empty)
    byod["csv_header_only"] = "loaded"
except Exception as exc:
    byod["csv_header_only"] = repr(exc)[:200]
txt = work / "c.txt"
txt.write_text("\n\n".join(f"Paragraph {k} of a text corpus with words." for k in range(14)), encoding="utf-8")
byod["txt_14_paragraphs"] = {k: len(v) for k, v in split(load_byod(txt), seed=42).items()}
record("P3_byod", byod)

# ---- P4 stand-in model: rerun semantics ------------------------------------------------------------
import torch  # noqa: E402
from transformers import GPT2Config, GPT2LMHeadModel  # noqa: E402

torch.manual_seed(0)
cfg = GPT2Config(vocab_size=50257, n_positions=1024, n_embd=32, n_layer=12, n_head=2)
base_state = {k: v.clone() for k, v in GPT2LMHeadModel(cfg).state_dict().items()}


def make_pipe():
    model = GPT2LMHeadModel(cfg)
    model.load_state_dict(base_state)
    model.eval()

    def tokenize(text):
        return list(text.encode("utf-8"))

    def scorer(ids):
        x = torch.tensor([ids])
        with torch.inference_mode():
            logits = model(input_ids=x, attention_mask=torch.ones_like(x)).logits
        lp = torch.log_softmax(logits[0, :-1].float(), dim=-1)
        return (-lp.gather(1, x[0, 1:, None])[:, 0]).tolist()

    def runner(prompt_ids, settings):
        x = torch.tensor([prompt_ids])
        with torch.inference_mode():
            out = model.generate(x, attention_mask=torch.ones_like(x), max_new_tokens=settings["max_new_tokens"],
                                 do_sample=False, pad_token_id=50256, eos_token_id=50256)
        return out[0, len(prompt_ids):].tolist()

    P = ns["GPT2TextGenerationPipeline"]
    return P(tokenize, runner, lambda ids: bytes(i for i in ids if i < 256).decode("utf-8", "replace"),
             "cpu", "stand-in", _scorer=scorer, _model=model, _tokenizer=object())


try:
    t0 = time.perf_counter()
    tr = [{"id": f"t{k}", "text": f"Abstract {k}: we propose a method for task {k % 5} and show results."} for k in range(24)]
    va = [{"id": f"v{k}", "text": f"Abstract v{k}: we study a method for task {k % 5} with experiments."} for k in range(8)]
    te = [{"id": f"e{k}", "text": f"Abstract e{k}: we present a method for task {k % 5} and analyse it."} for k in range(10)]
    pipe = make_pipe()
    frozen_before = pipe.evaluate(te)
    a1 = pipe.adapt(tr, va, epochs=2, lr=1e-3, batch_size=8, trainable_blocks=4)
    # "Re-run from Section 4 / Section 6" without reloading Section 3: the 'frozen' evaluation
    frozen_on_rerun = pipe.evaluate(te)
    # Optional experiment: TRAINABLE_BLOCKS = 1, re-running Section 7 onward
    a2 = pipe.adapt(tr, va, epochs=1, lr=1e-3, batch_size=8, trainable_blocks=1)
    in_memory = pipe.evaluate(te[:5])["perplexity"]
    art = work / "adapter"
    import shutil
    shutil.rmtree(art, ignore_errors=True)
    pipe.save_artifact(art)
    manifest = json.loads((art / "manifest.json").read_text(encoding="utf-8"))
    fresh = make_pipe()
    # load_artifact checks base identity against MODEL_ID/REVISION/WEIGHT_SHA256 constants, which the
    # manifest carries from the module, so the stand-in passes the identity check.
    fresh.load_artifact(art)
    reloaded = fresh.evaluate(te[:5])["perplexity"]
    record("P4_standin_rerun_semantics", {
        "ok": True, "seconds": round(time.perf_counter() - t0, 1),
        "frozen_test_ppl_first_run": round(frozen_before["perplexity"], 4),
        "frozen_test_ppl_on_rerun_without_section3": round(frozen_on_rerun["perplexity"], 4),
        "frozen_on_rerun_reports_adapted": frozen_on_rerun["adapted"],
        "first_adapt_history_val_ppl": [round(h["val"]["perplexity"], 4) for h in a1["history"]],
        "second_adapt_epoch0_note": a2["history"][0].get("note"),
        "second_adapt_epoch0_val_ppl": round(a2["history"][0]["val"]["perplexity"], 4),
        "artifact_tensor_count": len(manifest["tensors"]),
        "artifact_trainable_blocks": manifest["adapter"]["trainable_blocks"],
        "reload_parity_ppl_in_memory": round(in_memory, 6),
        "reload_parity_ppl_reloaded": round(reloaded, 6),
        "cell23_parity_assert_would_pass": abs(in_memory - reloaded) < 1e-6,
    })
except Exception as exc:
    import traceback
    record("P4_standin_rerun_semantics", {"ok": False, "error": traceback.format_exc()[-1200:]})

# ---- P5 generator / validator --------------------------------------------------------------------
p5 = {}
for name, cmd in {"build_notebook_check": [sys.executable, "tools/build_notebook.py", "--check"],
                  "validate_release_assets": [sys.executable, "tools/validate_release_assets.py"]}.items():
    r = subprocess.run(cmd, cwd=REPO, capture_output=True, text=True, timeout=300)
    p5[name] = {"exit": r.returncode, "tail": (r.stdout + r.stderr)[-400:]}
record("P5_generator_validator", p5)

# ---- source manifest -----------------------------------------------------------------------------
files = ["tutorials/gpt2_text_generation_colab.ipynb", "tutorials/README.md", "docs/release-verification.md",
         "STATUS.md", "README.md", "tools/build_notebook.py", "tools/notebook_template.py",
         "tools/validate_release_assets.py", "src/gpt2_text_generation_pipeline/pipeline.py",
         "src/gpt2_text_generation_pipeline/samples.py", "src/gpt2_text_generation_pipeline/metrics.py",
         "pyproject.toml"]
(OUT / "source_manifest.json").write_text(json.dumps({f: sha256(REPO / f) for f in files}, indent=2), encoding="utf-8")
print(json.dumps(results, indent=1, default=str)[:6000])
